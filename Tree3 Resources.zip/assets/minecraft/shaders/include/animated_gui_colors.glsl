#version 330

layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};

const float ANIMATED_GUI_TAU = 6.28318530718;

bool animated_gui_is_outline(vec4 color) {
    float brightness = max(max(color.r, color.g), color.b);
    float saturation = brightness - min(min(color.r, color.g), color.b);
    return color.a > 0.18 && color.a < 0.42 && brightness > 0.08 && saturation > 0.06;
}

bool animated_gui_matches_magenta(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    vec3 c = color / brightness;
    return c.r > 0.86 && c.g < 0.14 && c.b > 0.78;
}

bool animated_gui_matches_purple(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    vec3 c = color / brightness;
    return c.r > 0.50 && c.r < 0.72 && c.g < 0.14 && c.b > 0.86;
}

bool animated_gui_matches_cyan(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    vec3 c = color / brightness;
    return c.r < 0.14 && c.g > 0.86 && c.b > 0.78;
}

bool animated_gui_matches_yellow(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    vec3 c = color / brightness;
    return c.r > 0.86 && c.g > 0.86 && c.b < 0.18;
}

bool animated_gui_matches_red(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    vec3 c = color / brightness;
    return c.r > 0.86 && c.g < 0.18 && c.b < 0.24;
}

vec3 animated_gui_hue_to_rgb(float hue) {
    vec3 p = abs(fract(vec3(hue) + vec3(0.0, 0.6666667, 0.3333333)) * 6.0 - 3.0);
    return clamp(p - 1.0, 0.0, 1.0);
}

vec3 animated_gui_color(vec4 original_color, vec2 tex_coord) {
    if (!animated_gui_is_outline(original_color)) {
        return original_color.rgb;
    }

    float brightness = max(max(original_color.r, original_color.g), original_color.b);
    float t = fract(GameTime * 192.0);
    float shimmer = 0.5 + 0.5 * sin(t * ANIMATED_GUI_TAU);

    if (animated_gui_matches_magenta(original_color.rgb)) {
        return animated_gui_hue_to_rgb(fract(t)) * brightness * (0.84 + shimmer * 0.16);
    }

    if (animated_gui_matches_cyan(original_color.rgb)) {
        return mix(vec3(0.0, 0.72, 1.0), vec3(0.12, 0.95, 1.0), shimmer) * brightness;
    }

    if (animated_gui_matches_purple(original_color.rgb)) {
        float strong_shimmer = 0.74 + 0.36 * shimmer;
        return mix(vec3(0.42, 0.0, 0.95), vec3(0.88, 0.42, 1.0), shimmer) * brightness * strong_shimmer;
    }

    if (animated_gui_matches_yellow(original_color.rgb)) {
        return mix(vec3(1.0, 0.55, 0.0), vec3(1.0, 1.0, 0.25), shimmer) * brightness;
    }

    if (animated_gui_matches_red(original_color.rgb)) {
        float fade = 0.75 + 0.25 * sin(t * ANIMATED_GUI_TAU * 2.0);
        vec3 red = mix(vec3(0.65, 0.0, 0.02), vec3(1.0, 0.10, 0.06), shimmer);
        return red * brightness * fade;
    }

    return original_color.rgb;
}
