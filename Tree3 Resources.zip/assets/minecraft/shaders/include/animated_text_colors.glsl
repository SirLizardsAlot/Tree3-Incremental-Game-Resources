#version 330

const float ANIMATED_TEXT_TAU = 6.28318530718;

vec3 animated_text_hue_to_rgb(float hue) {
    vec3 p = abs(fract(vec3(hue) + vec3(0.0, 0.6666667, 0.3333333)) * 6.0 - 3.0);
    return clamp(p - 1.0, 0.0, 1.0);
}

bool animated_text_is_main_text(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    return brightness >= 0.70;
}

bool animated_text_matches_magenta(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g < 0.10 && color.b > 0.84 && color.b < 0.985;
}

bool animated_text_matches_cyan(vec3 color) {
    return animated_text_is_main_text(color) && color.r < 0.10 && color.g > 0.90 && color.b > 0.84 && color.b < 0.985;
}

bool animated_text_matches_yellow(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g > 0.90 && color.b > 0.015 && color.b < 0.16;
}

bool animated_text_matches_lime(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.015 && color.r < 0.16 && color.g > 0.90 && color.b < 0.10;
}

bool animated_text_matches_purple(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.50 && color.r < 0.72 && color.g < 0.10 && color.b > 0.90;
}

bool animated_text_matches_rare_red(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g < 0.10 && color.b > 0.015 && color.b < 0.16;
}

vec3 animated_text_color(vec3 original_color) {
    float t = fract(GameTime * 192.0);
    float scan = sin((gl_FragCoord.x * 0.035) + (gl_FragCoord.y * 0.055) + (t * ANIMATED_TEXT_TAU));

    if (animated_text_matches_magenta(original_color)) {
        return animated_text_hue_to_rgb(fract(t + gl_FragCoord.x * 0.003 + gl_FragCoord.y * 0.002));
    }

    if (animated_text_matches_cyan(original_color)) {
        float wave = 0.5 + 0.5 * scan;
        return mix(vec3(0.0, 0.45, 1.0), vec3(0.25, 1.0, 1.0), wave);
    }

    if (animated_text_matches_yellow(original_color)) {
        float pulse = 0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU + gl_FragCoord.x * 0.02);
        return mix(vec3(1.0, 0.55, 0.0), vec3(1.0, 1.0, 0.25), pulse);
    }

    if (animated_text_matches_lime(original_color)) {
        float pulse = 0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU * 1.25 + gl_FragCoord.y * 0.03);
        return mix(vec3(0.05, 0.95, 0.25), vec3(0.0, 0.9, 0.75), pulse);
    }

    if (animated_text_matches_purple(original_color)) {
        float wave = 0.5 + 0.5 * scan;
        return mix(vec3(0.42, 0.0, 0.95), vec3(0.82, 0.42, 1.0), wave);
    }

    if (animated_text_matches_rare_red(original_color)) {
        float ember = 0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU * 1.7 + gl_FragCoord.x * 0.05);
        float flare = pow(0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU * 3.0 + gl_FragCoord.x * 0.13 + gl_FragCoord.y * 0.09), 8.0);
        vec3 base = mix(vec3(0.65, 0.0, 0.02), vec3(1.0, 0.18, 0.0), ember);
        return mix(base, vec3(1.0, 0.92, 0.35), flare);
    }

    return original_color;
}
