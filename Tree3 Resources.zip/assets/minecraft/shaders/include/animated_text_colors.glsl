#version 330

const float ANIMATED_TEXT_TAU = 6.28318530718;

vec3 animated_text_hue_to_rgb(float hue) {
    vec3 p = abs(fract(vec3(hue) + vec3(0.0, 0.6666667, 0.3333333)) * 6.0 - 3.0);
    return clamp(p - 1.0, 0.0, 1.0);
}

bool animated_text_is_main_text(vec3 color) {
    float brightness = max(max(color.r, color.g), color.b);
    return brightness >= 0.70;
}

bool animated_text_matches_magenta(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g < 0.10 && color.b > 0.84 && color.b < 0.985;
}

bool animated_text_matches_cyan(vec3 color) {
    return animated_text_is_main_text(color) && color.r < 0.10 && color.g > 0.90 && color.b > 0.84 && color.b < 0.985;
}

bool animated_text_matches_yellow(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g > 0.90 && color.b > 0.015 && color.b < 0.16;
}

bool animated_text_matches_lime(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.015 && color.r < 0.16 && color.g > 0.90 && color.b < 0.10;
}

bool animated_text_matches_purple(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.50 && color.r < 0.72 && color.g < 0.10 && color.b > 0.90;
}

bool animated_text_matches_rare_red(vec3 color) {
    return animated_text_is_main_text(color) && color.r > 0.90 && color.g < 0.10 && color.b > 0.015 && color.b < 0.16;
}

vec3 animated_text_color(vec3 original_color, vec2 text_coord) {
    float t = fract(GameTime * 192.0);
    vec2 locked_coord = fract(text_coord * 32.0);
    float scan = sin((locked_coord.x * 5.5) + (locked_coord.y * 8.0) + (t * ANIMATED_TEXT_TAU));

    if (animated_text_matches_magenta(original_color)) {
        float highlight = 0.5 + 0.5 * scan;
        vec3 base = animated_text_hue_to_rgb(fract(t));
        return base * (0.82 + highlight * 0.18);
    }

    if (animated_text_matches_cyan(original_color)) {
        float wave = 0.5 + 0.5 * scan;
        return mix(vec3(0.0, 0.72, 1.0), vec3(0.12, 0.95, 1.0), wave);
    }

    if (animated_text_matches_yellow(original_color)) {
        float pulse = 0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU + locked_coord.x * 4.0);
        return mix(vec3(1.0, 0.55, 0.0), vec3(1.0, 1.0, 0.25), pulse);
    }

    if (animated_text_matches_lime(original_color)) {
        float pulse = 0.5 + 0.5 * sin(t * ANIMATED_TEXT_TAU * 1.25 + locked_coord.y * 4.0);
        return mix(vec3(0.05, 0.95, 0.25), vec3(0.0, 0.9, 0.75), pulse);
    }

    if (animated_text_matches_purple(original_color)) {
        float wave = 0.5 + 0.5 * scan;
        return mix(vec3(0.42, 0.0, 0.95), vec3(0.82, 0.42, 1.0), wave);
    }

    if (animated_text_matches_rare_red(original_color)) {
        float wave = 0.5 + 0.5 * scan;
        float fade = 0.75 + 0.25 * sin(t * ANIMATED_TEXT_TAU * 2.0 + locked_coord.x * 4.0);
        vec3 red = mix(vec3(0.65, 0.0, 0.02), vec3(1.0, 0.10, 0.06), wave);
        return red * fade;
    }

    return original_color;
}
