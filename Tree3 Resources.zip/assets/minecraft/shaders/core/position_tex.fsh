#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:animated_gui_colors.glsl>

uniform sampler2D Sampler0;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }

    color.rgb = animated_gui_color(color, texCoord0);
    fragColor = color * ColorModulator;
}
