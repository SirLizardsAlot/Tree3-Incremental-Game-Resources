#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:animated_text_colors.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0).rrrr * vertexColor;
    if (color.a < 0.1) {
        discard;
    }

    color = color * ColorModulator;
    color.rgb = animated_text_color(color.rgb);
    fragColor = color;
}
