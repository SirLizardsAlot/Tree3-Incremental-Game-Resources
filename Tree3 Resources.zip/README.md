# Tree3 Resources

Minecraft Java resource pack for animated text colors and a full-screen title overlay glyph.

## Animated Text Colors

Use these exact colors in JSON text, signs, chat plugins, titles, scoreboards, item names, or text displays:

| Trigger color | Animation |
| --- | --- |
| `#fb00ff` | rainbow cycle |
| `#00d9ff` | blue/cyan wave |
| `#ffd400` | warm gold/orange pulse |
| `#39ff14` | green/teal pulse |
| `#9b4dff` | purple/violet wave |
| `#ff1744` | rare red flare |

Example command:

```mcfunction
/tellraw @p [{"text":"Rainbow ","color":"#fb00ff"},{"text":"Ocean ","color":"#00d9ff"},{"text":"Gold ","color":"#ffd400"},{"text":"Lime ","color":"#39ff14"},{"text":"Purple ","color":"#9b4dff"},{"text":"RARE","color":"#ff1744"}]
```

The shader checks close matches to these trigger colors, so ordinary nearby text colors should not animate by accident.

## Full-Screen Overlay Character

This pack adds a private-use character, `\uE000`, that renders as a huge white 16:9 rectangle. Color it in title text to make fades, flashes, tints, or screen overlays.

Example title:

```mcfunction
/title @p title {"text":"\uE000","color":"#000000"}
```

Use `/title @p times <fadeIn> <stay> <fadeOut>` to control the fade timing.

## Notes

- Built for Minecraft Java `1.21.11` style core shaders.
- Core shader resource packs are not an officially supported Mojang feature, so later versions can break them.
- To change the trigger colors or animation palettes, edit `assets/minecraft/shaders/include/animated_text_colors.glsl`.
