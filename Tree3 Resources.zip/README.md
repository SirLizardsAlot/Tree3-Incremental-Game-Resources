# Animated Text Colors

This is a Minecraft Java resource pack that replaces the vanilla text core shaders so specific text colors animate.

Target these colors in JSON text, signs, chat plugins, titles, scoreboards, item names, or text displays:

| Trigger color | Animation |
| --- | --- |
| `#ff00ff` / magenta | rainbow cycle |
| `#00ffff` / cyan | blue/cyan wave |
| `#ffff00` / yellow | warm gold/orange pulse |
| `#00ff00` / lime | green/teal pulse |

Animated trigger colors:

- Magenta: `#ff00ff`
- Cyan: `#00ffff`
- Yellow: `#ffff00`
- Lime: `#00ff00`

Example command:

```mcfunction
/tellraw @p [{"text":"Rainbow ","color":"#ff00ff"},{"text":"Ocean ","color":"#00ffff"},{"text":"Gold ","color":"#ffff00"},{"text":"Lime","color":"#00ff00"}]
```

You can also use section-sign formatting in places that support it:

```text
§x§f§f§0§0§f§fRainbow text
§x§0§0§f§f§f§fOcean text
§x§f§f§f§f§0§0Gold text
§x§0§0§f§f§0§0Lime text
```

## Install

Copy the `AnimatedTextColors` folder into:

```text
%APPDATA%\.minecraft\resourcepacks
```

Then enable it from Minecraft's resource pack screen.

## Notes

- Built for Minecraft Java `1.21.11` style core shaders.
- Core shader resource packs are not an officially supported Mojang feature, so later versions can break them.
- The shader checks color ratios, so text shadows and dimmer world text should still animate with the matching main color.
- To change the trigger colors or animation palettes, edit the helper functions near the top of the `.fsh` shader files.

## Full-Screen Overlay Character

This pack adds a private-use character, `\uE000`, that renders as a huge white 16:9 rectangle. Color it in title text to make fades, flashes, tints, or screen overlays.

Example title:

```mcfunction
/title @p title {"text":"\uE000","color":"#000000"}
```

Use `/title @p times <fadeIn> <stay> <fadeOut>` to control the fade timing.
