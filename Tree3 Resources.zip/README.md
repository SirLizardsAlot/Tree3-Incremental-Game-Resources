# Tree3 Resources

Minecraft Java resource pack for animated text colors and a full-screen title overlay glyph.

## Animated Text Colors

Use these exact colors in JSON text, signs, chat plugins, titles, scoreboards, item names, or text displays:

| Trigger color | Animation |
| --- | --- |
| `#ff00f0` | rainbow cycle |
| `#00fff0` | blue/cyan wave |
| `#ffff0f` | warm gold/orange pulse |
| `#0fff00` | green/teal pulse |
| `#9b00ff` | purple/violet wave |
| `#ff000f` | rare red flare |

Example command:

```mcfunction
/tellraw @p [{"text":"Rainbow ","color":"#ff00f0"},{"text":"Ocean ","color":"#00fff0"},{"text":"Gold ","color":"#ffff0f"},{"text":"Lime ","color":"#0fff00"},{"text":"Purple ","color":"#9b00ff"},{"text":"RARE","color":"#ff000f"}]
```

The shader checks close matches to these trigger colors, so ordinary nearby text colors should not animate by accident. These are intentionally "almost normal" colors for DF text codes: they look like familiar colors, but they are uncommon exact hex values.

## Full-Screen Overlay Character

This pack adds a private-use character, `\uE000`, that renders as a huge white 16:9 rectangle. Color it in title text to make fades, flashes, tints, or screen overlays.

Example title:

```mcfunction
/title @p title {"text":"\uE000","color":"#000000"}
```

Use `/title @p times <fadeIn> <stay> <fadeOut>` to control the fade timing.

## Notes

- Built for Minecraft Java `1.21.11` style core shaders.
- Core shader resource packs are not an officially supported Mojang feature, so later versions can break them.
- To change the trigger colors or animation palettes, edit `assets/minecraft/shaders/include/animated_text_colors.glsl`.
